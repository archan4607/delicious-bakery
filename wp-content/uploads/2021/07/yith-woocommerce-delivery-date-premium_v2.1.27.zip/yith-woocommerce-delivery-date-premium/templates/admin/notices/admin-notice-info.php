<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="notice notice-info" style="padding-right: 38px;position: relative;">
<p><?php echo esc_html( $message ); ?></p>
<?php if ( ! empty( $url ) ) : ?>
<a class="notice-dismiss" href="<?php echo esc_url( $url ); ?>"  style="text-decoration: none;"></a>
<?php endif; ?>
</div>
