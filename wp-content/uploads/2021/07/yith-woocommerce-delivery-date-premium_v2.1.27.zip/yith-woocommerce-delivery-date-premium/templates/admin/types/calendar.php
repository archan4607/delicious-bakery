<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>
<tbody>
	<tr>
		<td>
			<div id="ywcdd_general_calendar"></div>
		</td>
	</tr>
</tbody>
